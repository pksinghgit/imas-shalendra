package in.iaf.imas.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.iaf.imas.dao.CdDvdDistributionDao;
import in.iaf.imas.dao.CdDvdStockDao;
import in.iaf.imas.model.CdDvdDistribution;
import in.iaf.imas.model.CdDvdStock;
import in.iaf.imas.service.CdDvdDistributionService;
import in.iaf.imas.service.CdDvdStockService;
@Service
public class CdDvdStockServiceImpl implements CdDvdStockService {

	@Autowired
	private CdDvdStockDao cdDvdStockDao;

	@Override
	public List<CdDvdStock> getListByStatus(int status) {
		// TODO Auto-generated method stub
		return cdDvdStockDao.getListByStatus(status);
		
		
		
	}

}
