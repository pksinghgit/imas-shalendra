package in.iaf.imas.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import in.iaf.imas.model.*;
import in.iaf.imas.service.CdDvdStockService;
import in.iaf.imas.service.GenericService;

@Controller
public class CdDvdDistributionController {

	@Autowired
	private GenericService genericService;
	
	@Autowired
	private CdDvdStockService cdDvdStockService;

	@RequestMapping(value = "/cdDvdDistribution", method = RequestMethod.GET)
	public ModelAndView cdDvdDistribution() {
		ModelAndView model = new ModelAndView("cdDvdDistribution");
		List<CdDvdDistribution> list = genericService.getAll(new CdDvdDistribution());
		model.addObject("list", list);
		model.addObject("CdDvdDistribution", new CdDvdDistribution());
		model.addObject("stockList", cdDvdStockService.getListByStatus(1));
		model.addObject("unitList", genericService.getAll(new UnitMaster()));

		return model;
	}

	@RequestMapping(value = "/addCdDvdDistribution", method = RequestMethod.POST)
	public String addCdDvdDistribution(@ModelAttribute("cdDvdDistribution") CdDvdDistribution cdDvdDistribution) {
		YesNoMaster issuedOrNot = new YesNoMaster();
		issuedOrNot.setId(2);
		for (long dvdDistribution : cdDvdDistribution.getSelectedCdDvdStock()) {
			CdDvdDistribution cdDvdDistributionDB = new CdDvdDistribution();
			CdDvdStock cdDvdStock=	 genericService.getById(new CdDvdStock() , dvdDistribution);
			cdDvdDistributionDB.setCdDvdStock(cdDvdStock);
			cdDvdDistributionDB.setIssuedByPersonal(cdDvdDistribution.getIssuedByPersonal());
			cdDvdDistributionDB.setUnitPersonal(cdDvdDistribution.getUnitPersonal());
			cdDvdDistributionDB.setIssuedDate(cdDvdDistribution.getIssuedDate());
			cdDvdDistributionDB.setIsRetured(issuedOrNot);
			cdDvdDistributionDB.setRemarks(cdDvdDistribution.getRemarks());
			cdDvdDistributionDB.setSectionMaster(cdDvdDistribution.getSectionMaster());
			cdDvdDistributionDB.setUnitMaster(cdDvdDistribution.getUnitMaster());

			Boolean isIssued = genericService.add(cdDvdDistributionDB);

			if (isIssued) {
				cdDvdStock.setIssuedOrNot(issuedOrNot);
				Boolean isAdd = genericService.add(cdDvdStock);
			}

		}

		return "redirect:/cdDvdDistribution";
	}

	@RequestMapping(value = "/deleteCdDvdDistribution/{id}", method = RequestMethod.GET)
	public String deleteunitMaster(@PathVariable("id") long id) {

		try {
			CdDvdDistribution cdDvdDistribution = new CdDvdDistribution();
			cdDvdDistribution.setId(id);
			genericService.delete(cdDvdDistribution);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "redirect:/cdDvdDistribution";
	}

}
