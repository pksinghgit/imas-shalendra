package in.iaf.imas.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import in.iaf.imas.model.RoleMaster;
import in.iaf.imas.model.UnitMaster;
import in.iaf.imas.service.GenericService;
import in.iaf.imas.service.RoleMasterService;

@Controller
public class UnitMasterController {

	@Autowired
	private GenericService genericService;

	@RequestMapping(value = "/unitMaster", method = RequestMethod.GET)
	public ModelAndView unitMaster() {
		ModelAndView model = new ModelAndView("unitMaster");
		List<UnitMaster> list = genericService.getAll(new UnitMaster());
		model.addObject("unitMasterList", list);
		model.addObject("unitMaster", new UnitMaster());
		return model;
	}

	@RequestMapping(value = "/addUnitMaster", method = RequestMethod.POST)
	public String addUnitMaster(@ModelAttribute("unitMaster") UnitMaster unitMaster) {
		
		@SuppressWarnings("unused")
		Boolean isAdd = genericService.add(unitMaster);
		return "redirect:/unitMaster";
	}

	@RequestMapping(value = "/deleteunitMaster/{id}", method = RequestMethod.GET)
	public String deleteunitMaster(@PathVariable("id") long id) {

		try {
			UnitMaster unitMaster = new UnitMaster();
			unitMaster.setId(id);
			genericService.delete(unitMaster);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return "redirect:/unitMaster";
	}

	@RequestMapping(value = "/editUnitMaster/{id}", method = RequestMethod.GET)
	public ModelAndView editUnitMaster(@PathVariable("id") long id) {

		ModelAndView model = new ModelAndView("unitMasterEdit");

		try {
			UnitMaster elements = new UnitMaster();

			UnitMaster unitMaster = genericService.getById(elements, id);
			model.addObject("unitMaster", unitMaster);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return model;
	}

}
