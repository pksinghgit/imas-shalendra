package in.iaf.imas.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.iaf.imas.dao.RoleMasterDao;
import in.iaf.imas.model.RoleMaster;
import in.iaf.imas.service.RoleMasterService;
@Service
public class RoleMasterServiceImpl implements RoleMasterService {
	@Autowired
	private RoleMasterDao roleMasterDao;

	@Override
	public boolean add(RoleMaster roleMaster) {
		// TODO Auto-generated method stub
		return roleMasterDao.add(roleMaster);
	}

	@Override
	public List<RoleMaster> getList() {
		// TODO Auto-generated method stub
		return roleMasterDao.getList();
	}

	@Override
	public RoleMaster getById(long id) {
		// TODO Auto-generated method stub
		return roleMasterDao.getById(id);
	}

	@Override
	public boolean delete(long id) {
		// TODO Auto-generated method stub
		return roleMasterDao.delete(id);
	}

}
