package in.iaf.imas.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.iaf.imas.dao.GenericDao;
import in.iaf.imas.service.GenericService;

@Service
public class GenericServiceImpl implements GenericService {
	@Autowired
	private GenericDao genericDao;

	@Override
	public <E> boolean add(E elements) {
		// TODO Auto-generated method stub
		return genericDao.add(elements);
	}

	@Override
	public <E> boolean delete(E elements) {
		// TODO Auto-generated method stub
		return genericDao.delete(elements);
	}

	@Override
	public <E> boolean update(E elements) {
		// TODO Auto-generated method stub
		return genericDao.update(elements);
	}

	@Override
	public <E> List<E> getAll(E elements) {
		// TODO Auto-generated method stub
		return genericDao.getAll(elements);
	}

	@Override
	public <E> E getById(E elements, long id) {
		// TODO Auto-generated method stub
		return genericDao.getById(elements, id);
	}

	@Override
	public <E> List<E> getAllByColumnIdLong(E elements, String columnName, long columnId) {
		// TODO Auto-generated method stub
		return genericDao.getAllByColumnIdLong(elements, columnName, columnId);
	}

	@Override
	public <E> List<E> getAllByColumnIdString(E elements, String columnName, String columnId) {
		// TODO Auto-generated method stub
		return genericDao.getAllByColumnIdString(elements, columnName, columnId);
	}

	@Override
	public <E> E getByColumnIdLongSingle(E elements, String columnName, long columnId) {
		// TODO Auto-generated method stub
		return genericDao.getByColumnIdLongSingle(elements, columnName, columnId);
	}

	@Override
	public <E> E getByColumnIdStringSingle(E elements, String columnName, String columnId) {
		// TODO Auto-generated method stub
		return genericDao.getByColumnIdStringSingle(elements, columnName, columnId);
	}

	@Override
	public <E> List<E> getAllByThreeColumn(E elements, E firstColumnn, E firstColumnValue, E secondColumn,
			E secondColumnValue) {
		// TODO Auto-generated method stub
		return genericDao.getAllByThreeColumn(elements, firstColumnn, firstColumnValue, secondColumn,
				secondColumnValue);
	}

}
