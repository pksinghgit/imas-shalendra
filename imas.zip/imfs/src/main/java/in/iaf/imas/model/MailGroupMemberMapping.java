package in.iaf.imas.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "mail_group_member_mapping")
public class MailGroupMemberMapping extends BaseClass {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	@ManyToOne
	private MailGroupMaster mailGroupMaster;
	@ManyToOne
	private User mailGroupMember;

	@Transient
	private List<Long> users;

	@ManyToOne
	private User groupOwner;

	@ManyToOne
	private YesNoMaster isDelete;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public MailGroupMaster getMailGroupMaster() {
		return mailGroupMaster;
	}

	public void setMailGroupMaster(MailGroupMaster mailGroupMaster) {
		this.mailGroupMaster = mailGroupMaster;
	}

	public User getMailGroupMember() {
		return mailGroupMember;
	}

	public void setMailGroupMember(User mailGroupMember) {
		this.mailGroupMember = mailGroupMember;
	}

	public YesNoMaster getIsDelete() {
		return isDelete;
	}

	public void setIsDelete(YesNoMaster isDelete) {
		this.isDelete = isDelete;
	}

	public User getGroupOwner() {
		return groupOwner;
	}

	public void setGroupOwner(User groupOwner) {
		this.groupOwner = groupOwner;
	}

	public List<Long> getUsers() {
		return users;
	}

	public void setUsers(List<Long> users) {
		this.users = users;
	}

}
