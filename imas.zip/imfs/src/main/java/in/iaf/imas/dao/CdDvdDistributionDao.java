package in.iaf.imas.dao;

import java.util.List;

import in.iaf.imas.model.CdDvdDistribution;

public interface CdDvdDistributionDao {
	public List<CdDvdDistribution> getListByStatus(int status);
}
