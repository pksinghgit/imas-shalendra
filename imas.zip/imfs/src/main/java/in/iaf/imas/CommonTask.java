package in.iaf.imas;

import in.iaf.imas.controller.KBroadcastController;

public class CommonTask {

	public CommonTask() {

		KBroadcastController broadcastController = new KBroadcastController();
		broadcastController.routineMethod();

	}

}
