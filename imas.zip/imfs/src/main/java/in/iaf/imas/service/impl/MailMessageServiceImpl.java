package in.iaf.imas.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.iaf.imas.dao.MailMessageDao;
import in.iaf.imas.model.MailGroupMaster;
import in.iaf.imas.model.User;
import in.iaf.imas.model.MailMessage;
import in.iaf.imas.service.MailMessageService;

@Service
public class MailMessageServiceImpl implements MailMessageService {

	@Autowired
	private MailMessageDao mailMessageDao;

	@Override
	public List<MailMessage> getMailMessgeByMember(User mailGroupMember) {
		// TODO Auto-generated method stub
		return mailMessageDao.getMailMessgeByMember(mailGroupMember);
	}

	@Override
	public List<MailMessage> getMailMessgeByGroup(MailGroupMaster groupMaster) {
		// TODO Auto-generated method stub
		return mailMessageDao.getMailMessgeByGroup(groupMaster);
	}

}
