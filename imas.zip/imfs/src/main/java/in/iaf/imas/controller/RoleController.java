package in.iaf.imas.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import in.iaf.imas.model.RoleMaster;
import in.iaf.imas.service.GenericService;
import in.iaf.imas.service.RoleMasterService;

@Controller
public class RoleController {
	@Autowired
	private RoleMasterService roleMasterService;
	@Autowired
	private GenericService genericService;

	@RequestMapping(value = "/roleMaster", method = RequestMethod.GET)
	public ModelAndView roleMaster() {
		ModelAndView model = new ModelAndView("role_master");
		List<RoleMaster> roleMasterList = genericService.getAll(new RoleMaster());
		model.addObject("roleMasterList", roleMasterList);
		model.addObject("roleMaster", new RoleMaster());
		return model;
	}

	@RequestMapping(value = "/addRoleMaster", method = RequestMethod.POST)
	public String addRoleMaster(@ModelAttribute("roleMaster") RoleMaster roleMaster) {
		roleMasterService.add(roleMaster);

		Boolean isAdd = genericService.add(roleMaster);

		return "redirect:/roleMaster";
	}

	@RequestMapping(value = "/deleteRoleMaster/{roleId}", method = RequestMethod.GET)
	public String deleteRoleMaster(@PathVariable("roleId") long roleId) {

		try {
			RoleMaster master = new RoleMaster();
			master.setId(roleId);
			genericService.delete(master);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "redirect:/roleMaster";
	}

}
