package in.iaf.imas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import in.iaf.imas.controller.KBroadcastController;

@SpringBootApplication
@EnableScheduling
public class ImasApplication {

	static KBroadcastController controller = new KBroadcastController();

	public static void main(String[] args) {
		SpringApplication.run(ImasApplication.class, args);
		
	}
}
