package in.iaf.imas.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import in.iaf.imas.dao.CdDvdDistributionDao;
import in.iaf.imas.model.CdDvdDistribution;
import in.iaf.imas.service.CdDvdDistributionService;

public class CdDvdDistributionServiceImpl implements CdDvdDistributionService {

	@Autowired
	private CdDvdDistributionDao cdDvdDistributionDao;
	
	@Override
	public List<CdDvdDistribution> getListByStatus(int status) {
		// TODO Auto-generated method stub
		return cdDvdDistributionDao.getListByStatus(status);
	}

}
