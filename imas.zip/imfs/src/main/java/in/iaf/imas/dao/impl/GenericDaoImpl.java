package in.iaf.imas.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import in.iaf.imas.dao.GenericDao;

@Repository
public class GenericDaoImpl<T> implements GenericDao {

	@Autowired
	private HibernateTemplate hibernateTemplate;

	@Override
	@Transactional(readOnly = false)
	public <E> boolean add(E elements) {
		try {

			hibernateTemplate.saveOrUpdate(elements);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	@Transactional(readOnly = false)
	public <E> boolean delete(E elements) {
		// TODO Auto-generated method stub

		try {
			hibernateTemplate.delete(elements);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

	}

	@Override
	public <E> boolean update(E elements) {
		try {

			try {
				hibernateTemplate.saveOrUpdate(elements);
				return true;
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public <E> List<E> getAll(E elements) {
		try {
			// sessionFactory.getCurrentSession().save(roleMaster);
			return (List<E>) hibernateTemplate.loadAll(elements.getClass());
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	@Override
	public <E> E getById(E elements, long id) {

		E obj = (E) hibernateTemplate.get(elements.getClass(), id);

		return obj;
	}

	@Override
	public <E> List<E> getAllByColumnIdLong(E elements, String columnName, long columnId) {

		String getTable = elements.getClass().toString().substring(elements.getClass().toString().lastIndexOf(".") + 1,
				elements.getClass().toString().length());

		@SuppressWarnings("unchecked")
		List<E> list = (List<E>) hibernateTemplate.find("from " + getTable + " where " + columnName + "=?", +columnId);

		return list;
	}

	@Override
	public <E> List<E> getAllByColumnIdString(E elements, String columnName, String columnId) {

		String getTable = elements.getClass().toString().substring(elements.getClass().toString().lastIndexOf(".") + 1,
				elements.getClass().toString().length());

		@SuppressWarnings("unchecked")
		List<E> list = (List<E>) hibernateTemplate.find("from " + getTable + " where " + columnName + "=?", columnId);

		return list;
	}

	@Override
	public <E> E getByColumnIdLongSingle(E elements, String columnName, long columnId) {
		String getTable = elements.getClass().toString().substring(elements.getClass().toString().lastIndexOf(".") + 1,
				elements.getClass().toString().length());

		@SuppressWarnings("unchecked")
		E record = (E) hibernateTemplate.find("from " + getTable + " where " + columnName + "=?", +columnId);

		return record;
	}

	@Override
	public <E> E getByColumnIdStringSingle(E elements, String columnName, String columnId) {

		String getTable = elements.getClass().toString().substring(elements.getClass().toString().lastIndexOf(".") + 1,
				elements.getClass().toString().length());

		@SuppressWarnings("unchecked")
		E record = (E) hibernateTemplate.find("from " + getTable + " where " + columnName + "=?", columnId).get(0);

		return record;
	}

	@Override
	public <E> List<E> getAllByThreeColumn(E elements, E firstColumnn, E firstColumnValue, E secondColumn,
			E secondColumnValue) {

		String getTable = elements.getClass().toString().substring(elements.getClass().toString().lastIndexOf(".") + 1,
				elements.getClass().toString().length());

		@SuppressWarnings("unchecked")
		List<E> list = (List<E>) hibernateTemplate.find("from " + getTable + " where " + firstColumnn + "="
				+ firstColumnValue + " and " + secondColumn + "=" + secondColumnValue);
		return list;
	}

}
