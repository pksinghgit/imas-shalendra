package in.iaf.imas.service;

import java.util.List;

import in.iaf.imas.model.User;
import in.iaf.imas.model.MailGroupMemberMapping;

public interface MailGroupMemberMappingService {

	public List<MailGroupMemberMapping> getMailGroupMemberMappingByMember(User mailGroupMember);

}
