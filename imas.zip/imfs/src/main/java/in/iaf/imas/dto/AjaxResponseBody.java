package in.iaf.imas.dto;

import java.util.List;

import in.iaf.imas.model.MailMessage;

public class AjaxResponseBody {

	String msg;
	List<MailMessage> result;

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public List<MailMessage> getResult() {
		return result;
	}

	public void setResult(List<MailMessage> result) {
		this.result = result;
	}

}
