package in.iaf.imas.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import in.iaf.imas.model.KBroadcast;
import in.iaf.imas.model.Permission;
import in.iaf.imas.model.PermissionRoleMapping;
import in.iaf.imas.model.RoleMaster;
import in.iaf.imas.model.User;
import in.iaf.imas.model.UserRoleMapping;
import in.iaf.imas.service.GenericService;
import in.iaf.imas.service.KBroadcastService;

@Controller
public class RoleUserMappingController {
	@Autowired
	private GenericService genericService;

	@RequestMapping(value = "/roleUserMappingAdmin", method = RequestMethod.GET)
	public ModelAndView roleUserMappingAdmin() {
		ModelAndView model = new ModelAndView("roleUserMappingAdmin");
		List<UserRoleMapping> list = genericService.getAll(new UserRoleMapping());
		model.addObject("list", list);
		model.addObject("roleList", genericService.getAll(new RoleMaster()));
		model.addObject("userList", genericService.getAll(new User()));
		model.addObject("userRoleMapping", new UserRoleMapping());
		return model;
	}

	@RequestMapping(value = "/addUserRoleMapping", method = RequestMethod.POST)
	public String addUserRoleMapping(@ModelAttribute("permissionRoleMapping") UserRoleMapping userRoleMapping)
			throws IOException {
		genericService.add(userRoleMapping);
		return "redirect:/roleUserMappingAdmin";
	}

	@RequestMapping(value = "/updateUserRoleMapping", method = RequestMethod.POST)
	public String updateUserRoleMapping(@ModelAttribute("permissionRoleMapping") UserRoleMapping userRoleMapping)
			throws IOException {
		genericService.add(userRoleMapping);
		return "redirect:/roleUserMappingAdmin";
	}

	@GetMapping(value = "/deleteUserRoleMapping/{id}")
	public String deleteUserRoleMapping(@PathVariable("id") long id) {

		try {
			UserRoleMapping userRoleMapping = new UserRoleMapping();
			userRoleMapping.setId(id);
			genericService.delete(userRoleMapping);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "redirect:/roleUserMappingAdmin";

		/*
		 * @GetMapping(value = "/editRolePermissionMappingAdmin/{kbId}") public
		 * ModelAndView editRolePermissionMappingAdmin(@PathVariable("kbId") long kbId)
		 * { ModelAndView model = new ModelAndView("kBroadcastAdminEdit"); try { //
		 * PermissionRoleMapping permissionRoleMapping = genericService.getAll(elements)
		 * // model.addObject("kBroadcast", kBroadcast); } catch (Exception e) {
		 * e.printStackTrace(); } return model;
		 * 
		 * }
		 */

	}
}
