package in.iaf.imas.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import in.iaf.imas.model.MailGroupMaster;
import in.iaf.imas.model.User;
import in.iaf.imas.model.YesNoMaster;
import in.iaf.imas.model.MailGroupMemberMapping;
import in.iaf.imas.model.PermissionRoleMapping;
import in.iaf.imas.service.GenericService;

@Controller
public class MailGroupMemberMappingController {
	@Autowired
	private GenericService genericService;

	@RequestMapping(value = "/mailGroupMemberMappingAdmin", method = RequestMethod.GET)
	public ModelAndView mailGroupMemberMappingAdmin(HttpSession httpSession) {
		User user = (User) httpSession.getAttribute("user");
		ModelAndView model = new ModelAndView("mailGroupMemberMappingAdmin");

		List<MailGroupMemberMapping> mailGroupMasterList = genericService
				.getAllByColumnIdLong(new MailGroupMemberMapping(), "isDelete.id", 1);

		List<Object> mailGroupMasterListDB = genericService.getAllByThreeColumn(new MailGroupMemberMapping(),
				"groupOwner.id", user.getId(), "isDelete.id", 1);

		model.addObject("mailGroupMemberMapping", new MailGroupMemberMapping());
		model.addObject("list", mailGroupMasterListDB);
		model.addObject("groupMemberList", genericService.getAll(new User()));
		model.addObject("mailGroupMasterList",
				genericService.getAllByColumnIdLong(new MailGroupMaster(), "groupOwner.id", user.getId()));

		return model;
	}

	@RequestMapping(value = "/addGroupMemberMapping", method = RequestMethod.POST)
	public String addGroupMemberMapping(
			@ModelAttribute("mailGroupMemberMapping") MailGroupMemberMapping mailGroupMemberMapping,
			HttpSession httpSession) throws IOException {
		User user = (User) httpSession.getAttribute("user");
		YesNoMaster yesNoMaster = new YesNoMaster();
		yesNoMaster.setId(1);
		for (Long usr : mailGroupMemberMapping.getUsers()) {
			MailGroupMemberMapping mapping = new MailGroupMemberMapping();
			User mailGroupMember = new User();
			mailGroupMember.setId(usr);

			mapping.setMailGroupMember(mailGroupMember);
			mapping.setGroupOwner(user);
			mapping.setMailGroupMaster(mailGroupMemberMapping.getMailGroupMaster());
			mapping.setIsDelete(yesNoMaster);
			genericService.add(mapping);
		}

		return "redirect:/mailGroupMemberMappingAdmin";
	}

	@RequestMapping(value = "/updateGroupMemberMapping", method = RequestMethod.POST)
	public String updateGroupMemberMapping(
			@ModelAttribute("permissionRoleMapping") PermissionRoleMapping permissionRoleMapping) throws IOException {
		genericService.add(permissionRoleMapping);
		return "redirect:/rolePermissionMappingAdmin";
	}

	@GetMapping(value = "/deleteGroupMemberMapping/{id}")
	public String deleteGroupMemberMapping(@PathVariable("id") long id) {

		try {
			MailGroupMemberMapping mailGroupMemberMapping = new MailGroupMemberMapping();
			mailGroupMemberMapping.setId(id);
			genericService.delete(mailGroupMemberMapping);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "redirect:/mailGroupMemberMappingAdmin";

	}

	@GetMapping(value = "/disableGroupMemberMapping/{id}")
	public String disableGroupMemberMapping(@PathVariable("id") long id) {

		try {
			MailGroupMemberMapping mailGroupMemberMapping = genericService.getById(new MailGroupMemberMapping(), id);
			mailGroupMemberMapping.setId(id);
			YesNoMaster yesNoMaster = new YesNoMaster();
			yesNoMaster.setId(2);
			mailGroupMemberMapping.setIsDelete(yesNoMaster);
			genericService.add(mailGroupMemberMapping);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "redirect:/mailGroupMemberMappingAdmin";

	}
}
