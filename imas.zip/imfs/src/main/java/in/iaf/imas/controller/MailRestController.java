package in.iaf.imas.controller;

import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import in.iaf.imas.dto.SearchCriteria;
import in.iaf.imas.model.MailGroupMaster;
import in.iaf.imas.model.MailMessage;
import in.iaf.imas.model.User;
import in.iaf.imas.service.GenericService;

@RestController
public class MailRestController {
	@Autowired
	private GenericService genericService;

	@PostMapping("/api/getAllChatByMsgId")
	public ResponseEntity<?> getSearchResultViaAjax(@RequestBody SearchCriteria search, HttpSession httpSession) {
		List<String> oldMsgList = null;
		MailMessage result = new MailMessage();
		result.setReply("Hello Ajax");

		User user = (User) httpSession.getAttribute("user");

		MailGroupMaster mailGroupMaster = new MailGroupMaster();
		mailGroupMaster.setId(user.getId());

		MailMessage mailMessageDB = genericService.getById(new MailMessage(), search.getGroupId());

		String[] output = mailMessageDB.getDiscussion().split("<br/>");

		oldMsgList = Arrays.asList(output);

		return ResponseEntity.ok(oldMsgList);

	}

}
