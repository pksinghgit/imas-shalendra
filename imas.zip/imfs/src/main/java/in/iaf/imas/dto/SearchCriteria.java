package in.iaf.imas.dto;

import org.hibernate.validator.constraints.NotBlank;

public class SearchCriteria {

	@NotBlank(message = "username can't empty!")
	long groupId;

	public long getGroupId() {
		return groupId;
	}

	public void setGroupId(long groupId) {
		this.groupId = groupId;
	}

}