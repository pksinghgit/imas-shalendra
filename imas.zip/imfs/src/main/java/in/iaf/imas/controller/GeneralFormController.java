package in.iaf.imas.controller;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import in.iaf.imas.model.FileBucket;
import in.iaf.imas.model.FormTypeMaster;
import in.iaf.imas.model.GeneralForm;
import in.iaf.imas.model.KBroadcast;
import in.iaf.imas.service.GenericService;

@Controller
public class GeneralFormController {

	@Autowired
	private GenericService genericService;

	@RequestMapping(value = "/generalFormAdmin", method = RequestMethod.GET)
	public ModelAndView generalFormAdmin() {
		ModelAndView model = new ModelAndView("generalFormAdmin");
		List<GeneralForm> generalForms = genericService.getAll(new GeneralForm());
		model.addObject("generalForms", generalForms);
		model.addObject("FileBucket",new FileBucket());
		model.addObject("formTypeList", genericService.getAll(new FormTypeMaster()));
		model.addObject("generalForm", new GeneralForm());

		return model;
	}

	@RequestMapping(value = "/addGeneralForm", method = RequestMethod.POST)
	public String addGeneralForm(@ModelAttribute("FileBucket") FileBucket FileBucket) throws IOException {

		GeneralForm generalForm = new GeneralForm();

		MultipartFile multipartFile = FileBucket.getFile();
		generalForm.setDocumentName(multipartFile.getOriginalFilename());
		generalForm.setDocuments(multipartFile.getBytes());
		generalForm.setFormDescription(FileBucket.getKbContaints());
		generalForm.setDownloadLinkName(FileBucket.getDownloadLinkName());
		generalForm.setCreatedOn(new Date());
		genericService.add(generalForm);
		return "redirect:/generalFormAdmin";
	}

	@GetMapping(value = "/deleteGeneralForm/{id}")
	public String deleteGeneralForm(@PathVariable("id") long id) {

		GeneralForm generalForm = new GeneralForm();
		generalForm.setId(id);
		genericService.delete(generalForm);

		return "redirect:/kBroadcastAdmin";

	}

	@RequestMapping(value = { "/allowed/downloadGenralForm/{docId}" }, method = RequestMethod.GET)
	public void downloadGenralForm(@PathVariable("docId") long docId, HttpServletResponse response) {

		try {

			GeneralForm generalForm = genericService.getById(new GeneralForm(), docId);

			// response.setContentType(kBroadcasts.getKbContaints().toString());
			// response.setContentLength(kBroadcasts.getKbContaints().length());
			response.setHeader("content-disposition", "attachment;filename=\"" + generalForm.getDocumentName());

			FileCopyUtils.copy(generalForm.getDocuments(), response.getOutputStream());

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
