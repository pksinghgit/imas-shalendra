package in.iaf.imas.controller;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import in.iaf.imas.dao.GenericDao;
import in.iaf.imas.model.KBroadcast;
import in.iaf.imas.model.MailGroupMemberMapping;
import in.iaf.imas.model.MailMessage;
import in.iaf.imas.model.Permission;
import in.iaf.imas.model.PermissionRoleMapping;
import in.iaf.imas.model.User;
import in.iaf.imas.model.UserRoleMapping;
import in.iaf.imas.service.GenericService;
import in.iaf.imas.service.KBroadcastService;

@Controller
public class HomeController {

	@Autowired
	private KBroadcastService kBroadcastService;
	@Autowired
	private GenericService genericService;

	@GetMapping("/login")
	public ModelAndView login(Principal principal) {
		ModelAndView model = new ModelAndView("/menubar/login");
		return model;
	}

	@GetMapping("/")
	public ModelAndView index(Principal principal, HttpSession httpSession) {

		ModelAndView model = new ModelAndView("index");

		List<Permission> permissionList = genericService.getAll(new Permission());

		User dbUser = genericService.getByColumnIdStringSingle(new User(), "serviceNo", principal.getName());

		List<UserRoleMapping> userRoleMappingList = genericService.getAllByColumnIdLong(new UserRoleMapping(),
				"user.id", dbUser.getId());

		List<PermissionRoleMapping> perList = new ArrayList<>();

		for (UserRoleMapping userRoleMapping : userRoleMappingList) {
			List<PermissionRoleMapping> perListDB = genericService.getAllByColumnIdLong(new PermissionRoleMapping(),
					"roleMaster.id", userRoleMapping.getRoleMaster().getId());
			perList.addAll(perListDB);
		}

		httpSession.setAttribute("user", dbUser);
		httpSession.setAttribute("permissionListMenu", perList);

		List<MailGroupMemberMapping> groupList = genericService.getAllByColumnIdLong(new MailGroupMemberMapping(),
				"mailGroupMember.id", dbUser.getId());

		List<MailMessage> mailList = new ArrayList<>();

		for (MailGroupMemberMapping mailGroupMemberMapping : groupList) {

			List<MailMessage> mailList1 = genericService.getAllByColumnIdLong(new MailMessage(), "mailGroupMaster.id",
					mailGroupMemberMapping.getMailGroupMaster().getId());
			mailList.addAll(mailList1);

		}

		int OldMessage = 0;
		int newMessage = 0;
		int sentMessage = 0;

		for (MailMessage mailMessage : mailList) {
			if (mailMessage.getMsgOldNew().getId() == 1) {
				if (dbUser.getId() != mailMessage.getMessageCreateBy().getId()) {
					newMessage++;
				} else {
					sentMessage++;
				}

			} else {
				OldMessage++;
			}

		}

		model.addObject("mailList", mailList);
		model.addObject("OldMessage", OldMessage);
		model.addObject("newMessage", newMessage);

		return model;
	}

}
