package in.iaf.imas.dao;

import java.util.List;

import in.iaf.imas.model.KBroadcast;

public interface KBroadcastDao {

	public boolean add(KBroadcast kBroadcast);

	public List<KBroadcast> getList();

	public List<KBroadcast> getListByStatus(int status);

	public List<KBroadcast> getEnabledList();

	public KBroadcast getById(long id);

	public boolean delete(long id);
}
