package in.iaf.imas.controller;

import java.io.IOException;
import java.security.Principal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import in.iaf.imas.dto.*;

import in.iaf.imas.dto.SearchCriteria;
import in.iaf.imas.model.FileBucket;
import in.iaf.imas.model.KBroadcast;
import in.iaf.imas.model.MailGroupMaster;
import in.iaf.imas.model.User;
import in.iaf.imas.model.YesNoMaster;
import in.iaf.imas.model.MailGroupMemberMapping;
import in.iaf.imas.model.MailMessage;
import in.iaf.imas.service.GenericService;
import in.iaf.imas.service.MailGroupMemberMappingService;
import in.iaf.imas.service.MailMessageService;

@Controller
public class MailController {
	@Autowired
	private GenericService genericService;

	@Autowired
	private MailMessageService mailMessageService;

	@Autowired
	private MailGroupMemberMappingService mailGroupMemberMappingService;

	@RequestMapping(value = "/mailManagmentDesktop", method = RequestMethod.GET)
	public ModelAndView mailManagmentDesktop(Principal principal, HttpSession httpSession) {

		ModelAndView model = new ModelAndView("mailManagmentDesktop");
		return model;
	}

	@RequestMapping(value = "/mailManagementAdmin", method = RequestMethod.GET)
	public ModelAndView mailManagementAdmin(Principal principal, HttpSession httpSession) {
		ModelAndView model = new ModelAndView("mailManagementAdmin");

		User user = (User) httpSession.getAttribute("user");

		MailGroupMaster mailGroupMaster = new MailGroupMaster();
		mailGroupMaster.setId(user.getId());

		List<MailGroupMemberMapping> mailGroupMasterList = mailGroupMemberMappingService
				.getMailGroupMemberMappingByMember(user);

		List<MailMessage> mailMessage = new ArrayList<>();

		for (MailGroupMemberMapping mailGroupMemberMapping : mailGroupMasterList) {
			List<MailMessage> mailMessageDB = mailMessageService
					.getMailMessgeByGroup(mailGroupMemberMapping.getMailGroupMaster());
			mailMessage.addAll(mailMessageDB);
		}

		Collections.reverse(mailMessage);

		model.addObject("mailMessageList", mailMessage);
		model.addObject("messageSize", mailMessage.size());
		model.addObject("unitGroupList",
				genericService.getAllByColumnIdLong(new MailGroupMaster(), "groupOwner.id", user.getId()));
		model.addObject("mailMessage", new MailMessage());

		return model;
	}

	@RequestMapping(value = "/mailManagementAdminNew", method = RequestMethod.GET)
	public ModelAndView mailManagementAdminNew(Principal principal, HttpSession httpSession) {
		ModelAndView model = new ModelAndView("mailManagementAdminSent");

		User user = (User) httpSession.getAttribute("user");

		MailGroupMaster mailGroupMaster = new MailGroupMaster();
		mailGroupMaster.setId(user.getId());

		List<MailGroupMemberMapping> mailGroupMasterList = mailGroupMemberMappingService
				.getMailGroupMemberMappingByMember(user);

		List<MailMessage> mailMessage = new ArrayList<>();
		YesNoMaster newMessage = new YesNoMaster();
		newMessage.setId(1);
		for (MailGroupMemberMapping mailGroupMemberMapping : mailGroupMasterList) {
			List<MailMessage> mailMessageDB = genericService.getAllByColumnIdLong(new MailMessage(), "msgOldNew.id", 1);
			mailMessage.addAll(mailMessageDB);
		}

		Collections.reverse(mailMessage);

		model.addObject("mailMessageList", mailMessage);
		model.addObject("unitGroupList",
				genericService.getAllByColumnIdLong(new MailGroupMaster(), "groupOwner.id", user.getId()));
		model.addObject("mailMessage", new MailMessage());

		return model;
	}

	

	@RequestMapping(value = "/mailManagementAdminSent", method = RequestMethod.GET)
	public ModelAndView mailManagementAdminSent(Principal principal, HttpSession httpSession) {
		ModelAndView model = new ModelAndView("mailManagementAdminSent");

		User user = (User) httpSession.getAttribute("user");

		MailGroupMaster mailGroupMaster = new MailGroupMaster();
		mailGroupMaster.setId(user.getId());

		List<MailGroupMemberMapping> mailGroupMasterList = mailGroupMemberMappingService
				.getMailGroupMemberMappingByMember(user);

		List<MailMessage> mailMessage = new ArrayList<>();

		for (MailGroupMemberMapping mailGroupMemberMapping : mailGroupMasterList) {
			List<MailMessage> mailMessageDB = genericService.getAllByColumnIdLong(new MailMessage(), "msgOldNew.id", 1);
			mailMessage.addAll(mailMessageDB);
		}

		Collections.reverse(mailMessage);

		model.addObject("mailMessageList", mailMessage);
		model.addObject("unitGroupList",
				genericService.getAllByColumnIdLong(new MailGroupMaster(), "groupOwner.id", user.getId()));
		model.addObject("mailMessage", new MailMessage());

		return model;
	}

	@RequestMapping(value = "/mailManagementAdminInbox", method = RequestMethod.GET)
	public ModelAndView mailManagementAdminInbox(Principal principal, HttpSession httpSession) {
		ModelAndView model = new ModelAndView("mailManagementAdmin");

		User user = (User) httpSession.getAttribute("user");

		MailGroupMaster mailGroupMaster = new MailGroupMaster();
		mailGroupMaster.setId(user.getId());

		/*
		 * List<MailGroupMemberMapping> mailGroupMasterList =
		 * mailGroupMemberMappingService .getMailGroupMemberMappingByMember(user);
		 */

		List<MailGroupMemberMapping> mailGroupMasterList = genericService
				.getAllByColumnIdLong(new MailGroupMemberMapping(), "isDelete.id", 1);
		List<MailMessage> mailMessage = mailMessageService
				.getMailMessgeByGroup(mailGroupMasterList.get(0).getMailGroupMaster());

		model.addObject("mailMessageList", mailMessage);
		model.addObject("unitGroupList", genericService.getAll(new MailGroupMaster()));
		model.addObject("mailMessage", new MailMessage());

		return model;
	}

	@RequestMapping(value = "/addMailMessage", method = RequestMethod.POST)
	public String addMailMessage(@ModelAttribute("mailMessage") MailMessage mailMessage, HttpSession httpSession)
			throws IOException, ParseException {

		User user = (User) httpSession.getAttribute("user");
		mailMessage.setMessageCreateBy(user);
		mailMessage.setCreatedBy(user.getId());
		mailMessage.setCreatedOn(new Date());
		YesNoMaster msgOldNew = new YesNoMaster();
		msgOldNew.setId(1);
		for (Long groupId : mailMessage.getMultipleGroup()) {
			MailMessage mailMessageDB = new MailMessage();
			MailGroupMaster groupMaster = new MailGroupMaster();
			groupMaster.setId(groupId);

			mailMessageDB.setReply("");
			mailMessageDB.setMailGroupMaster(groupMaster);
			mailMessageDB.setCreatedBy(user.getId());
			mailMessageDB.setSubject(mailMessage.getSubject());
			mailMessageDB.setMessageText(mailMessage.getMessageText());
			mailMessageDB.setRefNo(mailMessage.getRefNo());
			mailMessageDB.setDated(mailMessage.getDated());
			mailMessageDB.setCreatedOn(new Date());
			mailMessageDB.setMessageCreateBy(user);
			mailMessageDB.setMsgOldNew(msgOldNew);
			mailMessageDB
					.setDiscussion(user.getfName().concat(" -> ").concat(mailMessage.getMessageText().concat("<br/>")));

			genericService.add(mailMessageDB);
		}

		return "redirect:/mailManagementAdmin";
	}

	@GetMapping(value = "/deleteMailMessage/{id}")
	public String deleteMailMessage(@PathVariable("id") long id) {

		try {
			MailMessage mailMessage = genericService.getById(new MailMessage(), id);

			genericService.delete(mailMessage);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "redirect:/mailManagementAdmin";

	}

	@GetMapping(value = "/editMailMessage/{id}")
	public ModelAndView editMailMessage(@PathVariable("id") long id) {
		ModelAndView model = new ModelAndView("kBroadcastAdminEdit");
		try {
			MailMessage mailMessage = genericService.getById(new MailMessage(), id);
			model.addObject("mailMessage", mailMessage);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return model;

	}

	@GetMapping(value = "/mailMessageReply/{id}")
	public ModelAndView mailMessageReply(@PathVariable("id") long id) {
		ModelAndView model = new ModelAndView("mailMessageReply");
		try {
			MailMessage mailMessage = genericService.getById(new MailMessage(), id);

			mailMessage.setMessageText(mailMessage.getMessageText().replaceAll("<br/>", "*"));
			mailMessage.setReply("");

			String[] output = mailMessage.getDiscussion().split("<br/>");
			List<String> oldMsgList = Arrays.asList(output);
			model.addObject("oldMsgList", oldMsgList);

			model.addObject("mailMessage", mailMessage);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return model;
	}

	@RequestMapping(value = "/addMailMessageReply", method = RequestMethod.POST)
	public String addMailMessageReply(@ModelAttribute("mailMessage") MailMessage mailMessage, HttpSession httpSession)
			throws IOException, ParseException {

		User user = (User) httpSession.getAttribute("user");

		MailMessage mailMessage2 = genericService.getById(new MailMessage(), mailMessage.getId());

		try {
			if (mailMessage2.getCreatedBy() == user.getId()) {
				mailMessage2.setMessageText(mailMessage2.getMessageText()
						.concat(user.getfName() + " -> " + mailMessage.getReply().concat("<br/>")));
			} else {
				mailMessage2.setReply(mailMessage2.getReply()
						+ "".concat(user.getfName() + " -> " + mailMessage.getReply().concat("<br/>")));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		mailMessage2.setReplyBy(user);
		YesNoMaster msgOldNew = new YesNoMaster();
		msgOldNew.setId(1);
		mailMessage2.setMsgOldNew(msgOldNew);
		mailMessage2.setUpdatedOn(new Date());

		String discussion = mailMessage2.getDiscussion()
				.concat(user.getfName() + " -> " + mailMessage.getReply().concat("<br/>"));

		mailMessage2.setDiscussion(discussion);
		YesNoMaster setOldMessage = new YesNoMaster();
		setOldMessage.setId(2);
		mailMessage2.setMsgOldNew(setOldMessage);
		genericService.add(mailMessage2);

		return "redirect:/mailManagementAdmin";

	}

}
