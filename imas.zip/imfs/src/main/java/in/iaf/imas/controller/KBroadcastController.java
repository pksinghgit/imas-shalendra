package in.iaf.imas.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import in.iaf.imas.model.FileBucket;
import in.iaf.imas.model.KBroadcast;
import in.iaf.imas.service.KBroadcastService;

@Controller
public class KBroadcastController {
	@Autowired
	private KBroadcastService kBroadcastService;

	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logoutPage(HttpServletRequest request, HttpServletResponse response) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if (auth != null) {
			new SecurityContextLogoutHandler().logout(request, response, auth);
		}
		return "redirect:/index";// You can redirect wherever you want, but generally it's a good practice to
										// show login screen again.
	}

	@RequestMapping(value = "/kBroadcastAdmin", method = RequestMethod.GET)
	public ModelAndView kBroadcastAdmin() {
		ModelAndView model = new ModelAndView("kBroadcastAdmin");
		List<KBroadcast> kBroadcasts = kBroadcastService.getList();
		List<KBroadcast> kBroadcastsEnabled = new ArrayList<>();

		for (KBroadcast kBroadcast : kBroadcasts) {
			if (kBroadcast.getIsEnable() == 0 || kBroadcast.getIsEnable() == 2) {
				kBroadcastsEnabled.add(kBroadcast);
			}
		}

		Collections.reverse(kBroadcastsEnabled);
		int totalActive = 0;
		int totalDeactive = 0;
		for (KBroadcast kBroadcast : kBroadcasts) {
			if (kBroadcast.getIsEnable() == 0) {
				totalActive++;
			} else {
				totalDeactive++;
			}
		}

		model.addObject("kBroadcasts", kBroadcastsEnabled);
		model.addObject("FileBucket", new FileBucket());
		model.addObject("kBroadcast", new KBroadcast());
		model.addObject("total", kBroadcasts.size());
		model.addObject("totalDeactive", totalDeactive);
		model.addObject("totalActive", totalActive);

		return model;
	}

	@RequestMapping(value = "/kBroadcastAdminByStatus", method = RequestMethod.POST)
	public ModelAndView kBroadcastAdminByStatus(@ModelAttribute("kBroadcast") KBroadcast kBroadcast1) {
		ModelAndView model = new ModelAndView("kBroadcastAdmin");
		List<KBroadcast> kBroadcasts = null;
		if (kBroadcast1.getIsEnable() == 2) {
			kBroadcasts = kBroadcastService.getList();
		} else {

			kBroadcasts = kBroadcastService.getListByStatus(kBroadcast1.getIsEnable());
		}

		int totalActive = 0;
		int totalDeactive = 0;
		for (KBroadcast kBroadcast : kBroadcasts) {
			if (kBroadcast.getIsEnable() == 0) {
				totalActive++;
			} else if (kBroadcast.getIsEnable() == 1) {
				totalDeactive++;
			}
		}

		model.addObject("kBroadcasts", kBroadcasts);
		model.addObject("kBroadcast", new KBroadcast());
		model.addObject("FileBucket", new FileBucket());
		model.addObject("total", kBroadcasts.size());
		model.addObject("totalDeactive", totalDeactive);
		model.addObject("totalActive", totalActive);

		return model;
	}

	@RequestMapping(value = "/allowed/kBroadcast", method = RequestMethod.GET)
	public ModelAndView roleMasterManagement() {
		ModelAndView model = new ModelAndView("kbroadcast");
		List<KBroadcast> kBroadcasts = kBroadcastService.getEnabledList();
		Collections.reverse(kBroadcasts);

		model.addObject("kBroadcasts", kBroadcasts);
		return model;
	}

	@RequestMapping(value = "/addKBroadcast", method = RequestMethod.POST)
	public String addRoleMaster(@ModelAttribute("FileBucket") FileBucket FileBucket) throws IOException {

		KBroadcast kBroadcast = new KBroadcast();

		MultipartFile multipartFile = FileBucket.getFile();
		kBroadcast.setDocumentName(multipartFile.getOriginalFilename());
		kBroadcast.setDocuments(multipartFile.getBytes());
		kBroadcast.setDisableDate(FileBucket.getDisableDate());
		kBroadcast.setKbSectionName(FileBucket.getKbSectionName());
		kBroadcast.setKbContaints(FileBucket.getKbContaints());
		kBroadcast.setKbSubjet(FileBucket.getKbSubjet());
		kBroadcast.setDownloadLinkName(FileBucket.getDownloadLinkName());
		kBroadcast.setCreatedOn(new Date());

		kBroadcastService.add(kBroadcast);
		return "redirect:/kBroadcastAdmin";
	}

	@RequestMapping(value = "/updateKBroadcast", method = RequestMethod.POST)
	public String updateKBroadcast(@ModelAttribute("kBroadcast") KBroadcast kBroadcast) throws IOException {

		KBroadcast kBroadcast2 = kBroadcastService.getById(kBroadcast.getId());
		kBroadcast2.setKbSectionName(kBroadcast.getKbSectionName());
		kBroadcast2.setKbSubjet(kBroadcast.getKbSubjet());
		kBroadcast2.setKbContaints(kBroadcast.getKbContaints());
		kBroadcast2.setDisableDate(kBroadcast.getDisableDate());
		kBroadcast2.setDownloadLinkName(kBroadcast.getDownloadLinkName());
		kBroadcastService.add(kBroadcast2);
		return "redirect:/kBroadcastAdmin";
	}

	@GetMapping(value = "/deleteKB/{kbId}")
	public String deleteKB(@PathVariable("kbId") long kbId) {

		try {
			KBroadcast kBroadcast = kBroadcastService.getById(kbId);
			if (kBroadcast.getIsEnable() == 0) {
				kBroadcast.setIsEnable(1);
			} else {
				kBroadcast.setIsEnable(0);
			}

			kBroadcastService.add(kBroadcast);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "redirect:/kBroadcastAdmin";

	}

	@GetMapping(value = "/editKB/{kbId}")
	public ModelAndView editKBr(@PathVariable("kbId") long kbId) {
		ModelAndView model = new ModelAndView("kBroadcastAdminEdit");
		try {
			KBroadcast kBroadcast = kBroadcastService.getById(kbId);
			model.addObject("kBroadcast", kBroadcast);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return model;

	}

	@GetMapping(value = "/enableDisable/{kbId}")
	public String enableDisable(@PathVariable("kbId") long kbId) {

		try {
			KBroadcast kBroadcast = kBroadcastService.getById(kbId);
			if (kBroadcast.getIsEnable() == 0) {
				kBroadcast.setIsEnable(2);
				kBroadcast.setUpdatedOn(new Date());
			} else if (kBroadcast.getIsEnable() == 2) {
				kBroadcast.setIsEnable(0);
				kBroadcast.setUpdatedOn(new Date());
			}
			kBroadcastService.add(kBroadcast);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return "redirect:/kBroadcastAdmin";

	}

	// @Scheduled(cron = "*/5 * * * * ?")
	public void routineMethod() {
		System.out.println("hello boss");

		ScheduledExecutorService execService = Executors.newScheduledThreadPool(5);
		execService.scheduleAtFixedRate(() -> {
			List<KBroadcast> kBroadcast = kBroadcastService.getListByStatus(0);
			if (kBroadcast.size() > 0) {
				for (KBroadcast kBroadcast2 : kBroadcast) {
					if (kBroadcast2.getDisableDate().after(new Date())) {
						KBroadcast kBroadcastDelete = kBroadcastService.getById(kBroadcast2.getId());
						kBroadcastDelete.setIsEnable(1);
						kBroadcastService.add(kBroadcast2);
					}
				}
			}

			System.out.println("hi there at: " + new java.util.Date());
		}, 0, 20L, TimeUnit.SECONDS);

	}

	@RequestMapping(value = { "/allowed/downloadKB/{docId}" }, method = RequestMethod.GET)
	public void downloadAISL(@PathVariable("docId") long docId, HttpServletResponse response) {

		try {

			KBroadcast kBroadcasts = kBroadcastService.getById(docId);

			// response.setContentType(kBroadcasts.getKbContaints().toString());
			// response.setContentLength(kBroadcasts.getKbContaints().length());
			response.setHeader("content-disposition", "attachment;filename=\"" + kBroadcasts.getDocumentName());

			FileCopyUtils.copy(kBroadcasts.getDocuments(), response.getOutputStream());

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
