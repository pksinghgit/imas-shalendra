package in.iaf.imas.dao;

import java.util.List;

public interface GenericDao {

	public <E> boolean add(E elements);

	public <E> boolean delete(E elements);

	public <E> boolean update(E elements);

	public <E> List<E> getAll(E elements);

	public <E> List<E> getAllByColumnIdLong(E elements, String columnName, long columnId);

	public <E> List<E> getAllByColumnIdString(E elements, String columnName, String columnId);

	public <E> E getByColumnIdLongSingle(E elements, String columnName, long columnId);

	public <E> E getByColumnIdStringSingle(E elements, String columnName, String columnId);

	public <E> E getById(E elements, long id);

	public <E> List<E> getAllByThreeColumn(E elements, E firstColumnn, E firstColumnValue, E secondColumn,
			E secondColumnValue);
}
