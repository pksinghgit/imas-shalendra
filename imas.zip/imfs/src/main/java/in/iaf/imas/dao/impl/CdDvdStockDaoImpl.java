package in.iaf.imas.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import in.iaf.imas.dao.CdDvdDistributionDao;
import in.iaf.imas.dao.CdDvdStockDao;
import in.iaf.imas.model.CdDvdDistribution;
import in.iaf.imas.model.CdDvdStock;
@Repository
public class CdDvdStockDaoImpl implements CdDvdStockDao {
	@Autowired
	private HibernateTemplate hibernateTemplate;

	@Override
	public List<CdDvdStock> getListByStatus(int status) {
		// TODO Auto-generated method stub
		@SuppressWarnings("unchecked")
		List<CdDvdStock> list = (List<CdDvdStock>) hibernateTemplate.find("from CdDvdStock where issuedOrNot.id=?",new Long (status));
		return list;
	}

}
