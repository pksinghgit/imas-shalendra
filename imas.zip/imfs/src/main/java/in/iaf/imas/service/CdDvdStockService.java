package in.iaf.imas.service;



import java.util.List;

import in.iaf.imas.model.CdDvdDistribution;
import in.iaf.imas.model.CdDvdStock;
import in.iaf.imas.model.KBroadcast;



public interface CdDvdStockService {
	
	public List<CdDvdStock> getListByStatus(int status);

}
