package in.iaf.imas.model;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "general_form")
public class GeneralForm extends BaseClass {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@ManyToOne
	private UnitMaster unitMaster;
	@ManyToOne
	private FormTypeMaster formTypeMaster;

	@Lob
	private String formDescription;

	@Lob
	@Basic(fetch = FetchType.LAZY)
	private byte[] documents;

	private String downloadLinkName;

	private String documentName;

	@Transient
	private FileBucket fileBucket;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public UnitMaster getUnitMaster() {
		return unitMaster;
	}

	public void setUnitMaster(UnitMaster unitMaster) {
		this.unitMaster = unitMaster;
	}

	public FormTypeMaster getFormTypeMaster() {
		return formTypeMaster;
	}

	public void setFormTypeMaster(FormTypeMaster formTypeMaster) {
		this.formTypeMaster = formTypeMaster;
	}

	public String getFormDescription() {
		return formDescription;
	}

	public void setFormDescription(String formDescription) {
		this.formDescription = formDescription;
	}

	public byte[] getDocuments() {
		return documents;
	}

	public void setDocuments(byte[] documents) {
		this.documents = documents;
	}

	public String getDownloadLinkName() {
		return downloadLinkName;
	}

	public void setDownloadLinkName(String downloadLinkName) {
		this.downloadLinkName = downloadLinkName;
	}

	public FileBucket getFileBucket() {
		return fileBucket;
	}

	public void setFileBucket(FileBucket fileBucket) {
		this.fileBucket = fileBucket;
	}

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

}
