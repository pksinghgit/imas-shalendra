package in.iaf.imas.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "yes_no_master")
public class YesNoMaster extends BaseClass {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	private String yesNo;

	private String issuedOrNot;

	private String isDelete;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getYesNo() {
		return yesNo;
	}

	public void setYesNo(String yesNo) {
		this.yesNo = yesNo;
	}

	public String getIssuedOrNot() {
		return issuedOrNot;
	}

	public void setIssuedOrNot(String issuedOrNot) {
		this.issuedOrNot = issuedOrNot;
	}

	public String getIsDelete() {
		return isDelete;
	}

	public void setIsDelete(String isDelete) {
		this.isDelete = isDelete;
	}

}
