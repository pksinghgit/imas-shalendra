package in.iaf.imas.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import in.iaf.imas.dao.MailGroupMemberMappingDao;
import in.iaf.imas.model.User;
import in.iaf.imas.model.MailGroupMemberMapping;

@Repository
public class MailGroupMemberMappingDaoImpl implements MailGroupMemberMappingDao {
	@Autowired
	private HibernateTemplate hibernateTemplate;

	@Override
	public List<MailGroupMemberMapping> getMailGroupMemberMappingByMember(User mailGroupMember) {
		@SuppressWarnings("unchecked")
		List<MailGroupMemberMapping> list = (List<MailGroupMemberMapping>) hibernateTemplate.find(
				"from MailGroupMemberMapping where mailGroupMember.id=? and isDelete.id=?", mailGroupMember.getId(),
				new Long(1));
		return list;

	}

}
