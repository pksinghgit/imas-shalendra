package in.iaf.imas.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "user")
public class User extends BaseClass {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	private String serviceNo;

	@ManyToOne
	private RankMaster rankMaster;

	private String fName;

	private String motherName;

	private String favSportMan;

	private String lName;

	@Column(name = "PASSWORD", nullable = false)
	private String password;

	@Column(name = "ENABLED", nullable = false)
	private boolean enabled;

	@Transient
	private String confirmPassword;

	@ManyToOne
	private TradeMaster tradeMaster;

	@ManyToOne
	private UnitMaster unitMaster;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getServiceNo() {
		return serviceNo;
	}

	public void setServiceNo(String serviceNo) {
		this.serviceNo = serviceNo;
	}

	public RankMaster getRankMaster() {
		return rankMaster;
	}

	public void setRankMaster(RankMaster rankMaster) {
		this.rankMaster = rankMaster;
	}

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}

	public TradeMaster getTradeMaster() {
		return tradeMaster;
	}

	public void setTradeMaster(TradeMaster tradeMaster) {
		this.tradeMaster = tradeMaster;
	}

	public UnitMaster getUnitMaster() {
		return unitMaster;
	}

	public void setUnitMaster(UnitMaster unitMaster) {
		this.unitMaster = unitMaster;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	public String getMotherName() {
		return motherName;
	}

	public void setMotherName(String motherName) {
		this.motherName = motherName;
	}

	public String getFavSportMan() {
		return favSportMan;
	}

	public void setFavSportMan(String favSportMan) {
		this.favSportMan = favSportMan;
	}

	
}
