package in.iaf.imas.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import in.iaf.imas.model.User;
import in.iaf.imas.service.GenericService;

@Component("customUserDetailsService")
public class CustomUserDetailsService implements UserDetailsService {

	@Autowired
	private GenericService genericService;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

		List<User> user = genericService.getAllByColumnIdString(new User(), "serviceNo", username);

		
		return new org.springframework.security.core.userdetails.User(user.get(0).getServiceNo(),
				user.get(0).getPassword(), AuthorityUtils.createAuthorityList("ADMIN"));
	}

}
