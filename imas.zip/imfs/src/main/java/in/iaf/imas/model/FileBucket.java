package in.iaf.imas.model;

import java.util.Date;

import org.springframework.web.multipart.MultipartFile;

public class FileBucket {

	private MultipartFile file;

	private String kbSectionName;

	private String kbSubjet;
	private String kbContaints;

	private String refNo;

	private String signalDated;

	private String downloadLinkName;

	private FormTypeMaster formTypeMaster;

	private RankMaster rankMaster;

	private MailGroupMaster mailGroupMaster;
	
	private MailMessage mailMessage;

	private Date disableDate;

	public MultipartFile getFile() {
		return file;
	}

	public void setFile(MultipartFile file) {
		this.file = file;
	}

	public String getKbSectionName() {
		return kbSectionName;
	}

	public void setKbSectionName(String kbSectionName) {
		this.kbSectionName = kbSectionName;
	}

	public String getKbSubjet() {
		return kbSubjet;
	}

	public void setKbSubjet(String kbSubjet) {
		this.kbSubjet = kbSubjet;
	}

	public String getKbContaints() {
		return kbContaints;
	}

	public void setKbContaints(String kbContaints) {
		this.kbContaints = kbContaints;
	}

	public String getDownloadLinkName() {
		return downloadLinkName;
	}

	public void setDownloadLinkName(String downloadLinkName) {
		this.downloadLinkName = downloadLinkName;
	}

	public Date getDisableDate() {
		return disableDate;
	}

	public void setDisableDate(Date disableDate) {
		this.disableDate = disableDate;
	}

	public RankMaster getRankMaster() {
		return rankMaster;
	}

	public void setRankMaster(RankMaster rankMaster) {
		this.rankMaster = rankMaster;
	}

	public FormTypeMaster getFormTypeMaster() {
		return formTypeMaster;
	}

	public void setFormTypeMaster(FormTypeMaster formTypeMaster) {
		this.formTypeMaster = formTypeMaster;
	}

	public MailGroupMaster getMailGroupMaster() {
		return mailGroupMaster;
	}

	public void setMailGroupMaster(MailGroupMaster mailGroupMaster) {
		this.mailGroupMaster = mailGroupMaster;
	}

	public String getRefNo() {
		return refNo;
	}

	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}

	public String getSignalDated() {
		return signalDated;
	}

	public void setSignalDated(String signalDated) {
		this.signalDated = signalDated;
	}

}
