package in.iaf.imas.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "cd_dvd_master")
public class CdDvdMaster extends BaseClass {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	private String cdOrDvd;
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getCdOrDvd() {
		return cdOrDvd;
	}

	public void setCdOrDvd(String cdOrDvd) {
		this.cdOrDvd = cdOrDvd;
	}

}
