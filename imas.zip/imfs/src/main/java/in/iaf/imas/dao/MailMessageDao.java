package in.iaf.imas.dao;

import java.util.List;

import in.iaf.imas.model.MailGroupMaster;
import in.iaf.imas.model.User;
import in.iaf.imas.model.MailMessage;

public interface MailMessageDao {

	public List<MailMessage> getMailMessgeByMember(User mailGroupMember);

	public List<MailMessage> getMailMessgeByGroup(MailGroupMaster groupMaster);
}
