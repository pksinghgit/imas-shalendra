package in.iaf.imas.service;



import java.util.List;

import in.iaf.imas.model.CdDvdDistribution;
import in.iaf.imas.model.KBroadcast;



public interface CdDvdDistributionService {
	
	public List<CdDvdDistribution> getListByStatus(int status);

}
