/*package in.iaf.imas.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import in.iaf.imas.model.CdDvdMaster;
import in.iaf.imas.model.CdDvdStock;
import in.iaf.imas.model.UnitMaster;
import in.iaf.imas.model.YesNoMaster;
import in.iaf.imas.service.GenericService;

@Controller
public class CdDvdStockController {

	@Autowired
	private GenericService genericService;

	@RequestMapping(value = "/cdDvdStock", method = RequestMethod.GET)
	public ModelAndView cdDvdStock() {
		ModelAndView model = new ModelAndView("cdDvdStock");
		List<CdDvdStock> list = genericService.getAll(new CdDvdStock());
		model.addObject("cdDvdStockList", list);
		model.addObject("cdDvdStock", new CdDvdStock());
		model.addObject("cdDvdMaster", genericService.getAll(new CdDvdMaster()));
		return model;
	}

	@RequestMapping(value = "/addCdDvdStock", method = RequestMethod.POST)
	public String addCdDvdStock(@ModelAttribute("cdDvdStock") CdDvdStock cdDvdStock) {
		String details = "SCC";
		YesNoMaster master = new YesNoMaster();
		master.setId(1);
		for (int i = Integer.parseInt(cdDvdStock.getSlStart()); i <= (Integer.parseInt(cdDvdStock.getSlEnd())
				- Integer.parseInt(cdDvdStock.getSlStart()) + 1); i++) {
			String cdOrDvd = null;
			
			
			CdDvdStock cdDvdStockDB = new CdDvdStock();
			cdDvdStockDB.setCdDvdSlNo(i);
			cdDvdStockDB.setIssuedOrNot(master);

			if (cdDvdStock.getCdDvdMaster().getId() == 1) {
				cdOrDvd = "CDR";
			} else if (cdDvdStock.getCdDvdMaster().getId() == 2) {
				cdOrDvd = "DVDR";
			} else if (cdDvdStock.getCdDvdMaster().getId() == 3) {
				cdOrDvd = "DVDR DL";
			}

			String details1 = details + "/" + cdOrDvd + "/" + i + "/" + cdDvdStock.getYear();
			cdDvdStockDB.setCdOrDvdDetails(details1);
			cdDvdStockDB.setYear(cdDvdStock.getYear());
			cdDvdStockDB.setCdDvdMaster(cdDvdStock.getCdDvdMaster());
			Boolean isAdd = genericService.add(cdDvdStockDB);
			cdDvdStockDB = null;
			

		}

		return "redirect:/cdDvdStock";
	}

	@RequestMapping(value = "/deleteCdDvdStock/{id}", method = RequestMethod.GET)
	public String deleteunitMaster(@PathVariable("id") long id) {

		try {
			CdDvdStock cdDvdStock = new CdDvdStock();
			cdDvdStock.setId(id);
			genericService.delete(cdDvdStock);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return "redirect:/cdDvdStock";
	}

}
*/