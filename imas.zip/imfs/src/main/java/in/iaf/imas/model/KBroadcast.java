package in.iaf.imas.model;

import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.web.multipart.MultipartFile;

@Entity
@Table(name = "kbroadcast")
public class KBroadcast extends BaseClass {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	private String kbSectionName;

	private String kbSubjet;
	@Lob
	private String kbContaints;

	@Lob
	@Basic(fetch = FetchType.LAZY)
	private byte[] documents;

	private String documentName;

	private String downloadLinkName;

	private Date disableDate;
	
	private Integer isEnable = 2;

	
	@Transient
	private MultipartFile documentsDTO;
	@Transient
	private FileBucket fileBucket;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getKbSectionName() {
		return kbSectionName;
	}

	public void setKbSectionName(String kbSectionName) {
		this.kbSectionName = kbSectionName;
	}

	public String getKbSubjet() {
		return kbSubjet;
	}

	public void setKbSubjet(String kbSubjet) {
		this.kbSubjet = kbSubjet;
	}

	public String getKbContaints() {
		return kbContaints;
	}

	public void setKbContaints(String kbContaints) {
		this.kbContaints = kbContaints;
	}

	public byte[] getDocuments() {
		return documents;
	}

	public void setDocuments(byte[] documents) {
		this.documents = documents;
	}

	public MultipartFile getDocumentsDTO() {
		return documentsDTO;
	}

	public void setDocumentsDTO(MultipartFile documentsDTO) {
		this.documentsDTO = documentsDTO;
	}

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public String getDownloadLinkName() {
		return downloadLinkName;
	}

	public void setDownloadLinkName(String downloadLinkName) {
		this.downloadLinkName = downloadLinkName;
	}

	public Date getDisableDate() {
		return disableDate;
	}

	public void setDisableDate(Date disableDate) {
		this.disableDate = disableDate;
	}

	public Integer getIsEnable() {
		return isEnable;
	}

	public void setIsEnable(Integer isEnable) {
		this.isEnable = isEnable;
	}

	public FileBucket getFileBucket() {
		return fileBucket;
	}

	public void setFileBucket(FileBucket fileBucket) {
		this.fileBucket = fileBucket;
	}

}
