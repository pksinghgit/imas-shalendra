package in.iaf.imas.controller;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import ch.qos.logback.core.net.SyslogOutputStream;
import in.iaf.imas.model.KBroadcast;
import in.iaf.imas.service.KBroadcastService;

@Component
public class ScheduledTasks {

	@Autowired
	private KBroadcastService kBroadcastService;

	private static final SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");

	/*
	 * @Scheduled(fixedRate = 10000) public void performTask() {
	 * 
	 * System.out.println("Regular task performed at " + dateFormat.format(new
	 * Date()));
	 * 
	 * }
	 */

	/*
	 * @Scheduled(initialDelay = 1000, fixedRate = 10000) public void
	 * performDelayedTask() {
	 * 
	 * System.out.println("Delayed Regular task performed at " +
	 * dateFormat.format(new Date()));
	 * 
	 * }
	 */

	@Scheduled(cron = "*/5 23 * * * *")
	public void performTaskUsingCron() {

		List<KBroadcast> kBroadcasts = kBroadcastService.getListByStatus(0);
		SimpleDateFormat dateFormat = new SimpleDateFormat();

		System.out.println("Regular task performed using Cron at " + dateFormat.format(new Date()));

	}
}
