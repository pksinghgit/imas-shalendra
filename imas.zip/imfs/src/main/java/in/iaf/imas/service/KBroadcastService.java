package in.iaf.imas.service;



import java.util.List;

import in.iaf.imas.model.KBroadcast;



public interface KBroadcastService {

	public boolean add(KBroadcast kBroadcast);

	public List<KBroadcast> getList();
	
	public List<KBroadcast> getListByStatus(int status);
	
	public List<KBroadcast> getEnabledList();

	public KBroadcast getById(long id);

	public boolean delete(long id);

}
