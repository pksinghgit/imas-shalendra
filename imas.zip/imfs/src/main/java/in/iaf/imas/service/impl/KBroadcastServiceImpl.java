package in.iaf.imas.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import in.iaf.imas.dao.KBroadcastDao;
import in.iaf.imas.model.KBroadcast;
import in.iaf.imas.service.KBroadcastService;


@Service
@Transactional(readOnly = false)
public class KBroadcastServiceImpl implements KBroadcastService {
	
	@Autowired
	private KBroadcastDao kBroadcastDao;

	@Override
	public boolean add(KBroadcast kBroadcast) {
		// TODO Auto-generated method stub
		return kBroadcastDao.add(kBroadcast);
	}

	@Override
	public List<KBroadcast> getList() {
		// TODO Auto-generated method stub
		return kBroadcastDao.getList();
	}

	@Override
	public KBroadcast getById(long id) {
		// TODO Auto-generated method stub
		return kBroadcastDao.getById(id);
	}

	@Override
	public boolean delete(long id) {
		// TODO Auto-generated method stub
		return kBroadcastDao.delete(id);
	}

	@Override
	public List<KBroadcast> getEnabledList() {
		// TODO Auto-generated method stub
		return kBroadcastDao.getEnabledList();
	}

	@Override
	public List<KBroadcast> getListByStatus(int status) {
		// TODO Auto-generated method stub
		return kBroadcastDao.getListByStatus(status);
	}

}
