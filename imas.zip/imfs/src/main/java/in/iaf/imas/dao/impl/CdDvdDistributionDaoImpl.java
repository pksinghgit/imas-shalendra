package in.iaf.imas.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;

import in.iaf.imas.dao.CdDvdDistributionDao;
import in.iaf.imas.model.CdDvdDistribution;

public class CdDvdDistributionDaoImpl implements CdDvdDistributionDao {
	@Autowired
	private HibernateTemplate hibernateTemplate;

	@Override
	public List<CdDvdDistribution> getListByStatus(int status) {

		@SuppressWarnings("unchecked")
		List<CdDvdDistribution> list = (List<CdDvdDistribution>) hibernateTemplate.find("from CdDvdDistribution where isRetured=?", status);
		return list;
	}

}
