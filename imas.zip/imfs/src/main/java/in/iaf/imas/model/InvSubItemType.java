package in.iaf.imas.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "inv_sub_item_type")
public class InvSubItemType extends BaseClass {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	private String invSubItemType;
	@ManyToOne
	private InvItemTypeMaster invItemTypeMaster;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getInvSubItemType() {
		return invSubItemType;
	}
	public void setInvSubItemType(String invSubItemType) {
		this.invSubItemType = invSubItemType;
	}
	public InvItemTypeMaster getInvItemTypeMaster() {
		return invItemTypeMaster;
	}
	public void setInvItemTypeMaster(InvItemTypeMaster invItemTypeMaster) {
		this.invItemTypeMaster = invItemTypeMaster;
	}
	

}
