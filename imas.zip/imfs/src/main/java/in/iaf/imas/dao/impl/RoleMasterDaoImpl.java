package in.iaf.imas.dao.impl;



import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import in.iaf.imas.dao.RoleMasterDao;
import in.iaf.imas.model.RoleMaster;


@Repository
public class RoleMasterDaoImpl implements RoleMasterDao {
	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	@Transactional(readOnly = false)
	public boolean add(RoleMaster roleMaster) {
		try {
			//sessionFactory.getCurrentSession().save(roleMaster);
			hibernateTemplate.save(roleMaster);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public List<RoleMaster> getList() {
		// TODO Auto-generated method stub
		return hibernateTemplate.loadAll(RoleMaster.class);
	}

	@Override
	public RoleMaster getById(long id) {
		// TODO Auto-generated method stub
		return hibernateTemplate.get(RoleMaster.class, id);
	}

	@Override
	public boolean delete(long id) {
		try {
			hibernateTemplate.delete(hibernateTemplate.get(RoleMaster.class, id));
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

}
