package in.iaf.imas.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import in.iaf.imas.model.KBroadcast;
import in.iaf.imas.model.Permission;
import in.iaf.imas.model.PermissionRoleMapping;
import in.iaf.imas.model.RoleMaster;
import in.iaf.imas.service.GenericService;
import in.iaf.imas.service.KBroadcastService;

@Controller
public class RolePermissionMappingController {
	@Autowired
	private GenericService genericService;

	@RequestMapping(value = "/rolePermissionMappingAdmin", method = RequestMethod.GET)
	public ModelAndView roleMasterManagementAdmin() {
		ModelAndView model = new ModelAndView("rolePermissionMappingAdmin");
		List<PermissionRoleMapping> list = genericService.getAll(new PermissionRoleMapping());
		model.addObject("permissionRoleMapping", new PermissionRoleMapping());
		model.addObject("list", list);
		model.addObject("roleList", genericService.getAll(new RoleMaster()));
		model.addObject("permissionList", genericService.getAll(new Permission()));
		return model;
	}

	@RequestMapping(value = "/addRolePermissionMapping", method = RequestMethod.POST)
	public String addRolePermissionMapping(
			@ModelAttribute("permissionRoleMapping") PermissionRoleMapping permissionRoleMapping) throws IOException {
		genericService.add(permissionRoleMapping);
		return "redirect:/rolePermissionMappingAdmin";
	}

	@RequestMapping(value = "/updatePermissionRoleMapping", method = RequestMethod.POST)
	public String updatePermissionRoleMapping(
			@ModelAttribute("permissionRoleMapping") PermissionRoleMapping permissionRoleMapping) throws IOException {
		genericService.add(permissionRoleMapping);
		return "redirect:/rolePermissionMappingAdmin";
	}

	@GetMapping(value = "/deleteRolePermissionMapping/{id}")
	public String deleteRolePermissionMapping(@PathVariable("id") long id) {

		try {
			PermissionRoleMapping permissionRoleMapping = new PermissionRoleMapping();
			permissionRoleMapping.setId(id);
			genericService.delete(permissionRoleMapping);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "redirect:/rolePermissionMappingAdmin";

		/*
		 * @GetMapping(value = "/editRolePermissionMappingAdmin/{kbId}") public
		 * ModelAndView editRolePermissionMappingAdmin(@PathVariable("kbId") long kbId)
		 * { ModelAndView model = new ModelAndView("kBroadcastAdminEdit"); try { //
		 * PermissionRoleMapping permissionRoleMapping = genericService.getAll(elements)
		 * // model.addObject("kBroadcast", kBroadcast); } catch (Exception e) {
		 * e.printStackTrace(); } return model;
		 * 
		 * }
		 */

	}
}
