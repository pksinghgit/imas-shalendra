package in.iaf.imas.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import in.iaf.imas.dao.MailMessageDao;
import in.iaf.imas.model.MailGroupMaster;
import in.iaf.imas.model.User;
import in.iaf.imas.model.MailMessage;

@Repository
public class MailMessageDaoImpl implements MailMessageDao {

	@Autowired
	private HibernateTemplate hibernateTemplate;

	@Override
	public List<MailMessage> getMailMessgeByMember(User mailGroupMember) {
		@SuppressWarnings("unchecked")
		List<MailMessage> list = (List<MailMessage>) hibernateTemplate
				.find("from MailMessage where mailGroupMaster.id=?", mailGroupMember.getId());
		return list;
	}

	@Override
	public List<MailMessage> getMailMessgeByGroup(MailGroupMaster groupMaster) {
		@SuppressWarnings("unchecked")
		List<MailMessage> list = (List<MailMessage>) hibernateTemplate
				.find("from MailMessage where mailGroupMaster.id=?", groupMaster.getId());
		return list;
	}

}
