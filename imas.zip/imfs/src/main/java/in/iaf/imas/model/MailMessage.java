package in.iaf.imas.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.web.multipart.MultipartFile;

@Entity
@Table(name = "mail_group_message")
public class MailMessage extends BaseClass {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	private String refNo;

	private Date dated;

	private String subject;

	private String reply;

	@Lob
	private String messageText;

	@ManyToOne
	private YesNoMaster msgOldNew;

	@Lob
	private String discussion;

	@ManyToOne
	private MailMessageStatusMaster mailMessageStatusMaster;

	@ManyToOne
	private User messageCreateBy;

	@ManyToOne
	private User replyBy;

	@ManyToOne
	private MailGroupMaster mailGroupMaster;

	@Transient
	private List<Long> multipleGroup;

	@Lob
	@Basic(fetch = FetchType.LAZY)
	private byte[] documents;

	private String documentName;

	@Transient
	private MultipartFile documentsDTO;

	@Transient
	private FileBucket fileBucket;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getRefNo() {
		return refNo;
	}

	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}

	public Date getDated() {
		return dated;
	}

	public void setDated(Date dated) {
		this.dated = dated;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getMessageText() {
		return messageText;
	}

	public void setMessageText(String messageText) {
		this.messageText = messageText;
	}

	public MailMessageStatusMaster getMailMessageStatusMaster() {
		return mailMessageStatusMaster;
	}

	public void setMailMessageStatusMaster(MailMessageStatusMaster mailMessageStatusMaster) {
		this.mailMessageStatusMaster = mailMessageStatusMaster;
	}

	public User getMessageCreateBy() {
		return messageCreateBy;
	}

	public void setMessageCreateBy(User messageCreateBy) {
		this.messageCreateBy = messageCreateBy;
	}

	public MailGroupMaster getMailGroupMaster() {
		return mailGroupMaster;
	}

	public void setMailGroupMaster(MailGroupMaster mailGroupMaster) {
		this.mailGroupMaster = mailGroupMaster;
	}

	public byte[] getDocuments() {
		return documents;
	}

	public void setDocuments(byte[] documents) {
		this.documents = documents;
	}

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public MultipartFile getDocumentsDTO() {
		return documentsDTO;
	}

	public void setDocumentsDTO(MultipartFile documentsDTO) {
		this.documentsDTO = documentsDTO;
	}

	public FileBucket getFileBucket() {
		return fileBucket;
	}

	public User getReplyBy() {
		return replyBy;
	}

	public void setReplyBy(User replyBy) {
		this.replyBy = replyBy;
	}

	public void setFileBucket(FileBucket fileBucket) {
		this.fileBucket = fileBucket;
	}

	public List<Long> getMultipleGroup() {
		return multipleGroup;
	}

	public void setMultipleGroup(List<Long> multipleGroup) {
		this.multipleGroup = multipleGroup;
	}

	public String getReply() {
		return reply;
	}

	public void setReply(String reply) {
		this.reply = reply;
	}

	public String getDiscussion() {
		return discussion;
	}

	public void setDiscussion(String discussion) {
		this.discussion = discussion;
	}

	public YesNoMaster getMsgOldNew() {
		return msgOldNew;
	}

	public void setMsgOldNew(YesNoMaster msgOldNew) {
		this.msgOldNew = msgOldNew;
	}

}
