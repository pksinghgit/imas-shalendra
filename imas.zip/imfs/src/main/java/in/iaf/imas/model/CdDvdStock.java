package in.iaf.imas.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "cd_dvd_stock")
public class CdDvdStock extends BaseClass {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	private String cdOrDvdDetails;
	@Transient
	private String slStart;
	@Transient
	private String slEnd;

	private String year;

	private long cdDvdSlNo;

	@ManyToOne
	private YesNoMaster issuedOrNot;

	private String remarks;

	@ManyToOne
	private CdDvdMaster cdDvdMaster;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getCdOrDvdDetails() {
		return cdOrDvdDetails;
	}

	public void setCdOrDvdDetails(String cdOrDvdDetails) {
		this.cdOrDvdDetails = cdOrDvdDetails;
	}

	public CdDvdMaster getCdDvdMaster() {
		return cdDvdMaster;
	}

	public void setCdDvdMaster(CdDvdMaster cdDvdMaster) {
		this.cdDvdMaster = cdDvdMaster;
	}

	public String getSlStart() {
		return slStart;
	}

	public void setSlStart(String slStart) {
		this.slStart = slStart;
	}

	public String getSlEnd() {
		return slEnd;
	}

	public void setSlEnd(String slEnd) {
		this.slEnd = slEnd;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public long getCdDvdSlNo() {
		return cdDvdSlNo;
	}

	public void setCdDvdSlNo(long cdDvdSlNo) {
		this.cdDvdSlNo = cdDvdSlNo;
	}

	public YesNoMaster getIssuedOrNot() {
		return issuedOrNot;
	}

	public void setIssuedOrNot(YesNoMaster issuedOrNot) {
		this.issuedOrNot = issuedOrNot;
	}

}
