package in.iaf.imas.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import in.iaf.imas.dao.KBroadcastDao;
import in.iaf.imas.model.KBroadcast;

@Repository
public class KBroadcastDaoImpl implements KBroadcastDao {

	@Autowired
	private HibernateTemplate hibernateTemplate;

	@Override
	public boolean add(KBroadcast kBroadcast) {
		try {
			hibernateTemplate.saveOrUpdate(kBroadcast);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public List<KBroadcast> getList() {
		// TODO Auto-generated method stub
		return hibernateTemplate.loadAll(KBroadcast.class);
	}

	@Override
	public KBroadcast getById(long id) {
		// TODO Auto-generated method stub
		return hibernateTemplate.get(KBroadcast.class, id);
	}

	@Override
	public boolean delete(long id) {
		try {
			KBroadcast broadcast = new KBroadcast();
			broadcast.setId(id);
			hibernateTemplate.delete(broadcast);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public List<KBroadcast> getEnabledList() {

		@SuppressWarnings("unchecked")
		List<KBroadcast> list = (List<KBroadcast>) hibernateTemplate.find("from KBroadcast where isEnable=?", 0);
		return list;
	}

	@Override
	public List<KBroadcast> getListByStatus(int status) {
		@SuppressWarnings("unchecked")
		List<KBroadcast> list = (List<KBroadcast>) hibernateTemplate.find("from KBroadcast where isEnable=?", status);
		return list;
	}

}
