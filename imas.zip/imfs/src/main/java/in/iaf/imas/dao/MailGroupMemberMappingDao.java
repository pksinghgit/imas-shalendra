package in.iaf.imas.dao;

import java.util.List;

import in.iaf.imas.model.User;
import in.iaf.imas.model.MailGroupMemberMapping;

public interface MailGroupMemberMappingDao {

	public List<MailGroupMemberMapping> getMailGroupMemberMappingByMember(User mailGroupMember);

}
