package in.iaf.imas.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import in.iaf.imas.model.RoleMaster;
import in.iaf.imas.model.SectionMaster;
import in.iaf.imas.model.UnitMaster;
import in.iaf.imas.service.GenericService;
import in.iaf.imas.service.RoleMasterService;

@Controller
public class SectionMasterController {

	@Autowired
	private GenericService genericService;

	@RequestMapping(value = "/sectionMaster", method = RequestMethod.GET)
	public ModelAndView sectionMaster() {
		ModelAndView model = new ModelAndView("sectionMaster");
		List<SectionMaster> list = genericService.getAll(new SectionMaster());
		model.addObject("sectionMasterList", list);
		model.addObject("sectionMaster", new SectionMaster());
		model.addObject("unitMasterList", genericService.getAll(new UnitMaster()));
		return model;
	}

	@RequestMapping(value = "/addSectionMaster", method = RequestMethod.POST)
	public String addSectionMaster(@ModelAttribute("sectionMaster") SectionMaster sectionMaster) {
		@SuppressWarnings("unused")
		Boolean isAdd = genericService.add(sectionMaster);
		return "redirect:/sectionMaster";
	}

	@RequestMapping(value = "/deleteSectionMaster/{id}", method = RequestMethod.GET)
	public String deleteSectionMaster(@PathVariable("id") long id) {

		try {
			SectionMaster sectionMaster = new SectionMaster();
			sectionMaster.setId(id);
			genericService.delete(sectionMaster);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return "redirect:/sectionMaster";
	}

}
