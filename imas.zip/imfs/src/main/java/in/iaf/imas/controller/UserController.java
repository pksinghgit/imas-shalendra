package in.iaf.imas.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import in.iaf.imas.model.RankMaster;
import in.iaf.imas.model.TradeMaster;
import in.iaf.imas.model.UnitMaster;
import in.iaf.imas.model.User;
import in.iaf.imas.service.GenericService;

@Controller
public class UserController {

	@Autowired
	private GenericService genericService;

	private String userAlreadyExist;

	@RequestMapping(value = "/userAdmin", method = RequestMethod.GET)
	public ModelAndView userAdmin() {
		ModelAndView model = new ModelAndView("user");
		List<User> list = genericService.getAll(new User());
		model.addObject("mailGroupMemberList", list);
		model.addObject("mailGroupMember", new User());

		model.addObject("unitMasterList", genericService.getAll(new UnitMaster()));
		model.addObject("rankMasterList", genericService.getAll(new RankMaster()));
		model.addObject("tradeMasterList", genericService.getAll(new TradeMaster()));
		model.addObject("userAlreadyExist", userAlreadyExist);

		return model;
	}

	@RequestMapping(value = "/addMailGroupMember", method = RequestMethod.POST)
	public String addMailGroupMember(@ModelAttribute("groupMasterIMail") User mailGroupMember) {

		List<User> user = genericService.getAllByColumnIdString(new User(), "serviceNo",
				mailGroupMember.getServiceNo());

		if (mailGroupMember.getId() == 0) {
			if (user.size() == 0) {
				@SuppressWarnings("unused")
				BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
				mailGroupMember.setPassword(bCryptPasswordEncoder.encode(mailGroupMember.getServiceNo()));
				Boolean isAdd = genericService.add(mailGroupMember);
				userAlreadyExist = "User with Ser No." + mailGroupMember.getServiceNo() + " created successfully";
			} else {
				userAlreadyExist = "User with Ser No. " + mailGroupMember.getServiceNo() + " already exist.";
			}
		} else {
			user.get(0).setfName(mailGroupMember.getfName());
			user.get(0).setlName(mailGroupMember.getlName());
			user.get(0).setRankMaster(mailGroupMember.getRankMaster());
			user.get(0).setTradeMaster(mailGroupMember.getTradeMaster());
			user.get(0).setUnitMaster(mailGroupMember.getUnitMaster());
			user.get(0).setMotherName(mailGroupMember.getMotherName());
			user.get(0).setFavSportMan(mailGroupMember.getFavSportMan());

			Boolean isAdd = genericService.add(user.get(0));
		}

		return "redirect:/userAdmin";

	}

	@RequestMapping(value = "/deleteMailGroupMemberAdmin/{id}", method = RequestMethod.GET)
	public String deleteMailGroupMemberAdmin(@PathVariable("id") long id) {

		try {
			User mailGroupMember = new User();
			mailGroupMember.setId(id);
			genericService.delete(mailGroupMember);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return "redirect:/mailGroupMemberAdmin";
	}

	@RequestMapping(value = "/editUser", method = RequestMethod.GET)
	public ModelAndView editUser(HttpSession httpSession) {
		ModelAndView model = new ModelAndView("/userEdit");
		User user = (User) httpSession.getAttribute("user");
		model.addObject("unitMasterList", genericService.getAll(new UnitMaster()));
		model.addObject("rankMasterList", genericService.getAll(new RankMaster()));
		model.addObject("tradeMasterList", genericService.getAll(new TradeMaster()));

		try {
			User userDB = genericService.getById(new User(), user.getId());
			model.addObject("userDB", userDB);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return model;
	}

	@RequestMapping(value = "/editUser/{id}", method = RequestMethod.GET)
	public ModelAndView editUserById(@PathVariable("id") long id, HttpSession httpSession) {
		ModelAndView model = new ModelAndView("/userEdit");
		User user = (User) httpSession.getAttribute("user");
		model.addObject("unitMasterList", genericService.getAll(new UnitMaster()));
		model.addObject("rankMasterList", genericService.getAll(new RankMaster()));
		model.addObject("tradeMasterList", genericService.getAll(new TradeMaster()));

		try {
			User userDB = genericService.getById(new User(), user.getId());
			model.addObject("userDB", userDB);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return model;
	}

	@RequestMapping(value = "/changePassword", method = RequestMethod.GET)
	public ModelAndView changePassword(HttpSession httpSession) {
		ModelAndView model = new ModelAndView("/menubar/userChangePassword");
		User user = (User) httpSession.getAttribute("user");

		try {
			User userDB = genericService.getById(new User(), user.getId());
			userDB.setPassword(null);
			model.addObject("userDB", userDB);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return model;
	}

	@RequestMapping(value = "/changePasswordPost", method = RequestMethod.POST)
	public ModelAndView changePasswordPost(@ModelAttribute("user") User user, HttpSession httpSession) {
		ModelAndView model = new ModelAndView("redirect:/changePassword");
		try {
			User userDB = genericService.getById(new User(), user.getId());

			if (user.getPassword().toString().equals(user.getConfirmPassword().toString())) {
				BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
				userDB.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
				userDB.setUpdatedOn(new Date());
				userDB.setUpdatedBy(user.getId());
				genericService.add(userDB);
				userAlreadyExist = "Password Changed Successfully!";
			}

		} catch (Exception e) {
			userAlreadyExist = "Password and Re-Enter Password doen not match!";
			e.printStackTrace();
		}
		return model;
	}

	@RequestMapping(value = "/forgotPassword", method = RequestMethod.GET)
	public ModelAndView forgotPassword(HttpSession httpSession) {
		ModelAndView model = new ModelAndView("/menubar/forgotPassword");

		try {

			model.addObject("userDB", new User());

		} catch (Exception e) {
			e.printStackTrace();
		}
		return model;
	}

	@RequestMapping(value = "/forgotPassword", method = RequestMethod.POST)
	public ModelAndView forgotPasswordPost(@ModelAttribute("user") User user) {
		ModelAndView model = new ModelAndView("/menubar/forgotPassword");

		try {
			List<User> userDb = genericService.getAllByColumnIdString(new User(), "serviceNo", user.getServiceNo());
			if (userDb.size() > 0 && (user.getFavSportMan().equals(userDb.get(0).getFavSportMan()))
					&& (user.getMotherName().equals(userDb.get(0).getMotherName()))) {
				BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
				userDb.get(0).setPassword(encoder.encode(user.getPassword()));
				genericService.add(userDb.get(0));
				userAlreadyExist = "Password changed successfully!";
			} else {
				userAlreadyExist = "Please Enter Correct Details !";
			}
			model.addObject("userAlreadyExist", userAlreadyExist);
			model.addObject("userDB", new User());

		} catch (Exception e) {
			e.printStackTrace();
		}
		return model;
	}

	public String getUserAlreadyExist() {
		return userAlreadyExist;
	}

	public void setUserAlreadyExist(String userAlreadyExist) {
		this.userAlreadyExist = userAlreadyExist;
	}

}
