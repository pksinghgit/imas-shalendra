package in.iaf.imas.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import in.iaf.imas.model.KBroadcast;
import in.iaf.imas.model.Permission;
import in.iaf.imas.service.GenericService;

@Controller
public class PermissionController {

	@Autowired
	private GenericService genericService;

	@GetMapping(value = "permissionAdmin")
	public ModelAndView permissionAdmin() {
		ModelAndView model = new ModelAndView("permissionAdmin");
		model.addObject("permissionAdmin", new Permission());
		model.addObject("permissionListAdmin", genericService.getAll(new Permission()));
		return model;
	}

	@RequestMapping(value = "/addPermission", method = RequestMethod.POST)
	public String addRoleMaster(@ModelAttribute("kBroadcast") Permission permission) throws IOException {

		genericService.add(permission);

		return "redirect:/permissionAdmin";
	}
	
	
	@RequestMapping(value = "/deletePermission/{id}", method = RequestMethod.GET)
	public String deletePermission(@PathVariable("id") long id) {

		try {
			Permission permission=new Permission();
			permission.setId(id);
			genericService.delete(permission);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "redirect:/permissionAdmin";
	}

}
