package in.iaf.imas.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.iaf.imas.dao.MailGroupMemberMappingDao;
import in.iaf.imas.model.User;
import in.iaf.imas.model.MailGroupMemberMapping;
import in.iaf.imas.service.MailGroupMemberMappingService;

@Service
public class MailGroupMemberMappingServiceImpl implements MailGroupMemberMappingService {
	@Autowired
	private MailGroupMemberMappingDao mailGroupMemberMappingDao;
	

	@Override
	public List<MailGroupMemberMapping> getMailGroupMemberMappingByMember(User mailGroupMember) {
		// TODO Auto-generated method stub
		return mailGroupMemberMappingDao.getMailGroupMemberMappingByMember(mailGroupMember);
	}

}
