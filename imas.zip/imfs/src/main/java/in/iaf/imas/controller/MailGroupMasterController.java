package in.iaf.imas.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import in.iaf.imas.model.MailGroupMaster;
import in.iaf.imas.model.User;
import in.iaf.imas.service.GenericService;

@Controller
public class MailGroupMasterController {

	@Autowired
	private GenericService genericService;

	@RequestMapping(value = "/mailGroupMasterIMail", method = RequestMethod.GET)
	public ModelAndView mailGroupMasterIMail(HttpSession httpSession) {
		User user = (User) httpSession.getAttribute("user");
		ModelAndView model = new ModelAndView("mailGroupMasterIMail");
		List<MailGroupMaster> list = genericService.getAllByColumnIdLong(new MailGroupMaster(), "groupOwner.id",
				user.getId());
		model.addObject("GroupMasterIMailList", list);
		model.addObject("groupMasterIMail", new MailGroupMaster());
		return model;
	}

	@RequestMapping(value = "/addGroupMasterIMail", method = RequestMethod.POST)
	public String addGroupMasterIMail(@ModelAttribute("groupMasterIMail") MailGroupMaster groupMasterIMail,
			HttpSession httpSession) {

		User user = (User) httpSession.getAttribute("user");
		groupMasterIMail.setGroupOwner(user);
		@SuppressWarnings("unused")
		Boolean isAdd = genericService.add(groupMasterIMail);
		return "redirect:/mailGroupMasterIMail";
	}

	@RequestMapping(value = "/deleteGroupMasterIMail/{id}", method = RequestMethod.GET)
	public String deleteGroupMasterIMail(@PathVariable("id") long id) {

		try {
			MailGroupMaster groupMasterIMail = new MailGroupMaster();
			groupMasterIMail.setId(id);
			genericService.delete(groupMasterIMail);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return "redirect:/mailGroupMasterIMail";
	}

	@RequestMapping(value = "/editGroupMasterIMail/{id}", method = RequestMethod.GET)
	public ModelAndView editGroupMasterIMail(@PathVariable("id") long id) {

		ModelAndView model = new ModelAndView("groupMasterIMailEdit");

		try {
			MailGroupMaster groupMasterIMail = new MailGroupMaster();

			MailGroupMaster unitMaster = genericService.getById(groupMasterIMail, id);
			model.addObject("unitMaster", unitMaster);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return model;
	}

	// add new group member start

	// end add new group member

}
