package in.iaf.imas.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "cd_dvd_distribution")
public class CdDvdDistribution extends BaseClass {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@ManyToOne
	private CdDvdStock cdDvdStock;

	@Transient
	private List<Long> selectedCdDvdStock;

	@ManyToOne
	private UnitMaster unitMaster;

	@ManyToOne
	private SectionMaster sectionMaster;

	private String unitPersonal;

	private String issuedByPersonal;
	
	@ManyToOne
	private YesNoMaster isRetured;

	private String remarks;

	private Date issuedDate;

	private Date returnDate;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public CdDvdStock getCdDvdStock() {
		return cdDvdStock;
	}

	public void setCdDvdStock(CdDvdStock cdDvdStock) {
		this.cdDvdStock = cdDvdStock;
	}

	public SectionMaster getSectionMaster() {
		return sectionMaster;
	}

	public void setSectionMaster(SectionMaster sectionMaster) {
		this.sectionMaster = sectionMaster;
	}

	public String getUnitPersonal() {
		return unitPersonal;
	}

	public void setUnitPersonal(String unitPersonal) {
		this.unitPersonal = unitPersonal;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getIssuedByPersonal() {
		return issuedByPersonal;
	}

	public void setIssuedByPersonal(String issuedByPersonal) {
		this.issuedByPersonal = issuedByPersonal;
	}

	

	public Date getIssuedDate() {
		return issuedDate;
	}

	public void setIssuedDate(Date issuedDate) {
		this.issuedDate = issuedDate;
	}

	public Date getReturnDate() {
		return returnDate;
	}

	public void setReturnDate(Date returnDate) {
		this.returnDate = returnDate;
	}

	public UnitMaster getUnitMaster() {
		return unitMaster;
	}

	public void setUnitMaster(UnitMaster unitMaster) {
		this.unitMaster = unitMaster;
	}

	
	public List<Long> getSelectedCdDvdStock() {
		return selectedCdDvdStock;
	}

	public void setSelectedCdDvdStock(List<Long> selectedCdDvdStock) {
		this.selectedCdDvdStock = selectedCdDvdStock;
	}

	public YesNoMaster getIsRetured() {
		return isRetured;
	}

	public void setIsRetured(YesNoMaster isRetured) {
		this.isRetured = isRetured;
	}

}
