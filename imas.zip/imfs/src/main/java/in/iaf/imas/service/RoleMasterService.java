package in.iaf.imas.service;

import java.util.List;

import in.iaf.imas.model.RoleMaster;

public interface RoleMasterService {

	public boolean add(RoleMaster roleMaster);

	public List<RoleMaster> getList();

	public RoleMaster getById(long id);

	public boolean delete(long id);

}
